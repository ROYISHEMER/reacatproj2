import basket_icon from './basket_icon.png'
import logo from './logor.jpg'
import header_img from './רקע.jpg'
import search_icon from './search_icon.png'
import menu_1 from './BBB/logoBBB.png'
import menu_2 from './בורגר קינג/kinglogo.png'
import menu_3 from './בנדיקט/benedictlogo.png'
import menu_4 from './גפניקה/japanika.jpg'
import menu_5 from './גרג/landver.png'
import menu_6 from './דומינוס פיצה/dominoslogo.png'
import menu_7 from './מקדולנדס/mclogo.png'
import menu_8 from './מקסיקני/mexcicany.png'
import rating_starts from './rating_starts.png'
import food_1 from './BBB/chips.png'
import food_2 from './BBB/cruckpay.png'
import food_3 from './BBB/hambbb.png'
import food_4 from './BBB/tortia.png'
import food_5 from './בורגר קינג/burgrr.png'
import food_6 from './בורגר קינג/cruspy.png'
import food_7 from './בורגר קינג/nugets.png'
import food_8 from './בורגר קינג/yemchips.png'
import food_9 from './בנדיקט/bread.png'
import food_10 from './בנדיקט/crocmatho.png'
import food_11 from './בנדיקט/desert.png'
import food_12 from './בנדיקט/egs.png'
import food_13 from './גפניקה/desert.png'
import food_14 from './גפניקה/nugets.png'
import food_15 from './גפניקה/padtay.png'
import food_16 from './גפניקה/shoushi.png'
import food_17 from './גרג/coffi.png'
import food_18 from './גרג/rozalch.png'
import food_19 from './גרג/shnizel.png'
import food_20 from './גרג/tost.png'
import food_21 from './דומינוס פיצה/desert.png'
import food_22 from './דומינוס פיצה/garlic.png'
import food_23 from './דומינוס פיצה/peperoni.png'
import food_24 from './דומינוס פיצה/tometo.png'
import food_25 from './מקדולנדס/crispi.png'
import food_26 from './מקדולנדס/icrcrem.png'
import food_27 from './מקדולנדס/mcroyal.png'
import food_28 from './מקדולנדס/nugets.png'
import food_29 from './מקסיקני/cachos.png'
import food_30 from './מקסיקני/potetoballs.png'
import food_31 from './מקסיקני/tacos.png'
import food_32 from './מקסיקני/tortia.png'

import add_icon_white from './add_icon_white.png'
import add_icon_green from './add_icon_green.png'
import remove_icon_red from './remove_icon_red.png'
import app_store from './app_store.png'
import play_store from './play_store.png'
import linkedin_icon from './linkedin_icon.png'
import facebook_icon from './facebook_icon.png'
import twitter_icon from './twitter_icon.png'
import cross_icon from './cross_icon.png'
import selector_icon from './selector_icon.png'

export const assets = {
    logo,
    basket_icon,
    header_img,
    search_icon,
    rating_starts,
    add_icon_green,
    add_icon_white,
    remove_icon_red,
    app_store,
    play_store,
    linkedin_icon,
    facebook_icon,
    twitter_icon,
    cross_icon,
    selector_icon
}

export const menu_list = [
    {
        menu_name: "BBB",
        menu_image: menu_1
    },
    {
        menu_name: "BURGER KING",
        menu_image: menu_2
    },
    {
        menu_name: "BENEDICT",
        menu_image: menu_3
    },
    {
        menu_name: "Japanika",
        menu_image: menu_4
    },
    {
        menu_name: "Coffe Landver",
        menu_image: menu_5
    },
    {
        menu_name: "Domino's Pizza",
        menu_image: menu_6
    },
    {
        menu_name: "Mcdonald's",
        menu_image: menu_7
    },
    {
        menu_name: "The Mexicani",
        menu_image: menu_8
    }]

export const food_list = [
    {
        food_id: 1,
        food_name: "Chips",
        food_image: food_1,
        food_price: 12,
        food_desc: "Hot, fresh, and tasty chips with coarse salt, served with a variety of dips",
        food_category: "BBB"
    },
    {
        food_id: 2,
        food_name: "Crack Pie",
        food_image: food_2,
        food_price: 18,
        food_desc: "Crack Pie is sweet and tasty with a flaky crust, rich filling, and cinnamon",
        food_category: "BBB"
    }, {
        food_id: 3,
        food_name: "BBburger with fries",
        food_image: food_3,
        food_price: 16,
        food_desc: "The 220-gram burger comes with tomato, lettuce, pepper sauce, and purple onion. It's served with chips",
        food_category: "BBB"
    }, {
        food_id: 4,
        food_name: "Entrecote Tortilla",
        food_image: food_4,
        food_price: 24,
        food_desc: "A tortilla with 120 grams of entrecote meat comes with lettuce, avocado, spicy salsa, pickled lemon, and chips",
        food_category: "BBB"
    }, {
        food_id: 5,
        food_name: "The crispy burger meal",
        food_image: food_5,
        food_price: 14,
        food_desc: "The 200-gram burger with beer batter coating comes with chips and a choice of drink.",
        food_category: "BURGER KING"
    }, {
        food_id: 6,
        food_name: "The Double Crispy Bacon Burger meal",
        food_image: food_6,
        food_price: 18,
        food_desc: "The double 200-gram burger with beer batter coating comes with an extra topping of bacon on top, along with chips and a drink of your choice",
        food_category: "BURGER KING"
    }, {
        food_id: 7,
        food_name: "Chicken nuggets",
        food_image: food_7,
        food_price: 20,
        food_desc: "12 pieces of chicken nuggets come with a sauce of your choice",
        food_category: "BURGER KING"
    }, {
        food_id: 8,
        food_name: "Orange chips",
        food_image: food_8,
        food_price: 9,
        food_desc: "Fresh orange chips made from potato with coarse salt, served with mayonnaise and ketchup",
        food_category: "BURGER KING"
    }, {
        food_id: 9,
        food_name: "Bread basket",
        food_image: food_9,
        food_price: 5,
        food_desc: "The bread basket comes with honey, butter, chocolate spread, and apple jam",
        food_category: "BENEDICT"
    }, {
        food_id: 10,
        food_name: "KrukMatham",
        food_image: food_10,
        food_price: 22,
        food_desc: "Sweet brioch bread toasted with scrambled eggs and English sauce, with pork sausage",
        food_category: "BENEDICT"
    }, {
        food_id: 11,
        food_name: "Cloud pancakes",
        food_image: food_11,
        food_price: 12.5,
        food_desc: "Pancake with white chocolate sauce and condensed milk, with an additional topping of your choice",
        food_category: "BENEDICT"
    }, {
        food_id: 12,
        food_name: "Eags royal",
        food_image: food_12,
        food_price: 19,
        food_desc: "Brioche bread with smoked salmon, poached egg, and English sauce",
        food_category: "BENEDICT"
    },
    {
        food_id: 13,
        food_name: "Dark chocolate mousse",
        food_image: food_13,
        food_price: 5,
        food_desc: "Rich chocolate mousse with cocoa, butter, and a layer of white chocolate",
        food_category: "Japanika"
    },
    {
        food_id: 14,
        food_name: "Sweet and sour chicken",
        food_image: food_14,
        food_price: 18,
        food_desc: "Chicken with a crispy coating, served with sweet and sour sauce, green onions, and rice",
        food_category: "Japanika"
    }, {
        food_id: 15,
        food_name: "Pad Thai",
        food_image: food_15,
        food_price: 16,
        food_desc: "Spicy Pad Thai with chicken, purple onion, green onions, bean sprouts, peanuts, and a spicy Pad Thai sauce",
        food_category: "Japanika"
    }, {
        food_id: 16,
        food_name: "World Champion Sushi Combo",
        food_image: food_16,
        food_price: 24,
        food_desc: "3 rolls with red tuna, urban salmon, and salmon coated with Japanese egg omelette",
        food_category: "Japanika"
    }, {
        food_id: 17,
        food_name: "Café Hafuch",
        food_image: food_17,
        food_price: 5,
        food_desc: "Upside-down coffee with rich frothed milk",
        food_category: "Coffe Landver"
    }, {
        food_id: 18,
        food_name: "Roozalach",
        food_image: food_18,
        food_price: 12,
        food_desc: " 6 Half-baked croissants with chocolate/pistachio.",
        food_category: "Coffe Landver"
    }, {
        food_id: 19,
        food_name: "Schnitzel",
        food_image: food_19,
        food_price: 15,
        food_desc: "3 chicken schnitzels served with lettuce",
        food_category: "Coffe Landver"
    }, {
        food_id: 20,
        food_name: "Bulgarian toast",
        food_image: food_20,
        food_price: 11,
        food_desc: "Bagel toast with mozzarella cheese, Bulgarian cheese, olives, and onions",
        food_category: "Coffe Landver"
    }, {
        food_id: 21,
        food_name: "Cinnamon roll ",
        food_image: food_21,
        food_price: 10,
        food_desc: "A pastry with cinnamon and white chocolate sauce on a yeast dough",
        food_category: "Domino's Pizza"
    }, {
        food_id: 22,
        food_name: "Garlic bread",
        food_image: food_22,
        food_price: 4,
        food_desc: "Garlic bread with butter and parsley served with tomato sauce and olive oil",
        food_category: "Domino's Pizza"
    }, {
        food_id: 23,
        food_name: "Pepperoni pizza",
        food_image: food_23,
        food_price: 14,
        food_desc: "A pizza with pepperoni, green peppers, and garlic pepper sauce",
        food_category: "Domino's Pizza"
    }, {
        food_id: 24,
        food_name: "A pizza tomatoes broccoli",
        food_image: food_24,
        food_price: 12,
        food_desc: "A pizza with mozzarella, grilled tomatoes, and broccoli",
        food_category: "Domino's Pizza"
    },
    {
        food_id: 25,
        food_name: "The fish burger",
        food_image: food_25,
        food_price: 12,
        food_desc: "The burger with a 150-gram fish patty, served with pickles, lettuce, and mayonnaise",
        food_category: "Mcdonald's"
    },
    {
        food_id: 26,
        food_name: "Pistachio ice cream",
        food_image: food_26,
        food_price: 5,
        food_desc: "Ice cream with Oreo cookies",
        food_category: "Mcdonald's"
    }, {
        food_id: 27,
        food_name: "The 220-gram burger",
        food_image: food_27,
        food_price: 16,
        food_desc: "The burger with a 200-gram beef patty, served with pickles, lettuce, tomato, mayonnaise, and ketchup",
        food_category: "Mcdonald's"
    }, {
        food_id: 28,
        food_name: "Chicken nuggets",
        food_image: food_28,
        food_price: 24,
        food_desc: "8 pieces of chicken breast coated in breadcrumbs, served with a sauce of your choice",
        food_category: "Mcdonald's"
    }, {
        food_id: 29,
        food_name: "Fresh chips",
        food_image: food_29,
        food_price: 5,
        food_desc: "Potato chips with salt and pepper, served with a choice of dips",
        food_category: "The Mexicani"
    }, {
        food_id: 30,
        food_name: "Cheese balls",
        food_image: food_30,
        food_price: 10,
        food_desc: "Balls with mozzarella cheese, mashed potatoes, coated in toasted breadcrumbs",
        food_category: "The Mexicani"
    }, {
        food_id: 31,
        food_name: "Taco",
        food_image: food_31,
        food_price: 10,
        food_desc: "2 Taco with minced beef, spicy chili, pickled red onions, and cheese",
        food_category: "The Mexicani"
    }, {
        food_id: 32,
        food_name: "Burrito",
        food_image: food_32,
        food_price: 15,
        food_desc: "Burrito with rice and shredded entrecote meat, served with nachos and a choice of filling",
        food_category: "The Mexicani"
    }
]
