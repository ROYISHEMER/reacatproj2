import React, { useState } from 'react';
import Home from './pages/Home/Home';
import Footer from './components/Footer/Footer';
import Navbar from './components/Navbar/Navbar';
import { Routes, Route } from 'react-router-dom'; 
import Cart from './pages/Cart/Cart';
import LoginPopup from './components/LoginPopup/LoginPopup';
import PlaceOrder from './pages/PlaceOrder/PlaceOrder';
import UserManagementPage from './pages/UserManagement/UserManagementPage';

const App = () => {
    const [showLogin, setShowLogin] = useState(false);
    const [users, setUsers] = useState(JSON.parse(sessionStorage.getItem('users')) || []);

    const handleDeleteUser = (index) => {
        const updatedUsers = users.filter((_, i) => i !== index);
        setUsers(updatedUsers);
        sessionStorage.setItem('users', JSON.stringify(updatedUsers));
    };

    return (
        <>
            {showLogin ? <LoginPopup setShowLogin={setShowLogin} setUsers={setUsers} users={users} /> : null}
            <div className='app'>
                <Navbar setShowLogin={setShowLogin} />
                <Routes>
                    <Route path='/' element={<Home />} />
                    <Route path='/cart' element={<Cart />} />
                    <Route path='/order' element={<PlaceOrder />} />
                    <Route path='/user-management' element={<UserManagementPage users={users} onDeleteUser={handleDeleteUser} />} />
                </Routes>
            </div>
            <Footer />
        </>
    );
};

export default App;
