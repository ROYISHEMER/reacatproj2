import { createContext, useState } from "react";
import { food_list, menu_list } from "../assets/assets";

export const StoreContext = createContext(null);

const StoreContextProvider = ({ children }) => {
    const [cartItems, setCartItems] = useState({});
    const [ordersData, setOrdersData] = useState({});
    const [filteredItems, setFilteredItems] = useState([]);

    const addToCart = (itemId) => {
        if (!cartItems[itemId]) {
            setCartItems((prev) => ({ ...prev, [itemId]: 1 }));
        } else {
            setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] + 1 }));
        }
    };

    const removeFromCart = (itemId) => {
        if (cartItems[itemId] > 1) {
            setCartItems((prev) => ({ ...prev, [itemId]: prev[itemId] - 1 }));
        } else {
            const { [itemId]: value, ...rest } = cartItems;
            setCartItems(rest);
        }
    };

    const getTotalCartAmount = () => {
        let totalAmount = 0;
        Object.keys(cartItems).forEach((item) => {
            const itemInfo = food_list.find((product) => product.food_id === Number(item));
            if (itemInfo) {
                totalAmount += itemInfo.food_price * cartItems[item];
            }
        });
        return totalAmount;
    };

    const clearCart = () => {
        setCartItems({});
    };

    const placeOrder = (deliveryData) => {
        console.log("Order placed:", deliveryData);
        clearCart(); 
    };

    const contextValue = {
        food_list,
        menu_list,
        cartItems,
        addToCart,
        removeFromCart,
        getTotalCartAmount,
        placeOrder,
        clearCart,  
        filteredItems,
        setFilteredItems,
    };

    return (
        <StoreContext.Provider value={contextValue}>
            {children}
        </StoreContext.Provider>
    );
};

export default StoreContextProvider;
