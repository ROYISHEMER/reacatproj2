import React, { useState } from 'react';
import './LoginPopup.css';
import { assets } from '../../assets/assets';
import { useNavigate } from 'react-router-dom';

const LoginPopup = ({ setShowLogin, setUsers, users }) => {
    const [currState, setCurrState] = useState("Sign Up");
    const [name, setName] = useState('');  
    const [email, setEmail] = useState('');  
    const [password, setPassword] = useState('');
    const navigate = useNavigate();

    const handleSignUp = () => {
        const userExists = users.some(user => user.email === email || user.name === name);
        if (!userExists) {
            const newUser = {
                name,
                email,
                password,
                role: 'user'
            };
            const updatedUsers = [...users, newUser];
            setUsers(updatedUsers);
            sessionStorage.setItem('users', JSON.stringify(updatedUsers));
            alert('Registration successful, please login to continue.');
            setCurrState('Login'); 
        } else {
            alert('Email or username already exists.');
        }
    };

    const handleLogin = () => {
        if (name === 'admin' && password === 'admin') {
            alert('Admin login successful');
            navigate('/user-management');
        } else {
            const user = users.find(user => user.name === name && user.password === password);
            if (user) {
                sessionStorage.setItem('loggedInUser', JSON.stringify(user));
                alert('Login successful');
                setShowLogin(false);
                navigate('/');
            } else {
                alert('Invalid username or password');
            }
        }
    };

    return (
        <div className='login-popup'>
            <div className="login-popup-container">
                <div className="login-popup-title">
                    <h2>{currState}</h2>
                    <img onClick={() => setShowLogin(false)} src={assets.cross_icon} alt="Close" />
                </div>
                <div className="login-popup-inputs">
                    {currState === "Sign Up" && (
                        <>
                            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
                            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Email" />
                            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
                        </>
                    )}
                    {currState === "Login" && (
                        <>
                            <input type="text" value={name} onChange={(e) => setName(e.target.value)} placeholder="Name" />
                            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
                        </>
                    )}
                    <button onClick={currState === "Login" ? handleLogin : handleSignUp}>
                        {currState === "Login" ? "Login" : "Create account"}
                    </button>
                </div>
                <div className="login-popup-condition">
                    <input type="checkbox" name="" id="terms" />
                    <p>By continuing, I agree to the Terms of Use & Privacy Policy.</p>
                </div>
                {currState === "Login"
                    ? <p>Need to register? <span onClick={() => setCurrState('Sign Up')}>Click here</span></p>
                    : <p>Already have an account? <span onClick={() => setCurrState('Login')}>Login here</span></p>
                }
            </div>
        </div>
    );
};

export default LoginPopup;
