import React from 'react'
import './Header.css'

const Header = () => {
    return (
        <div className='header'>
            <div className='header-contents'>
                <h2>Order your favourite food here</h2>
                <p>Choose from the restaurant catalog the desired restaurant, then select which dishes you want. You can also choose multiple dishes from different places and combine them into one order. So go ahead, pick from the delicious selection and enjoy!</p>
                <button>View Menu</button>
            </div>
        </div>
    )
}

export default Header
