import React, { useContext, useState } from 'react';
import './Navbar.css';
import { assets } from '../../assets/assets';
import { Link } from 'react-router-dom';
import { StoreContext } from '../../Context/StoreContext';

const Navbar = ({ setShowLogin }) => {
    const [menu, setMenu] = useState("home");
    const { getTotalCartAmount, food_list, filteredItems, setFilteredItems } = useContext(StoreContext);
    const [isSearchOpen, setIsSearchOpen] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const loggedInUser = JSON.parse(sessionStorage.getItem('loggedInUser'));

    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchQuery(value);
        if (value === '') {
            setFilteredItems(food_list); 
        }
    };

    const handleSearch = () => {
        const results = food_list.filter(item => item.food_name.toLowerCase().includes(searchQuery.toLowerCase()));
        setFilteredItems(results);
    };

    const closeSearch = () => {
        setIsSearchOpen(false);
        setSearchQuery('');
        setFilteredItems(food_list); 
    };

    const handleLogout = () => {
        sessionStorage.removeItem('loggedInUser');
        window.location.reload();
    };

    return (
        <div className='navbar'>
            <Link to='/'><img className='logo' src={assets.logo} alt="" /></Link>
            <ul className="navbar-menu">
                <Link to="/" onClick={() => setMenu("home")} className={`${menu === "home" ? "active" : ""}`}>Home</Link>
                <a href='#explore-menu' onClick={() => setMenu("menu")} className={`${menu === "menu" ? "active" : ""}`}>Menu</a>
                <a href='#app-download' onClick={() => setMenu("mob-app")} className={`${menu === "mob-app" ? "active" : ""}`}>Mobile App</a>
                <a href='#footer' onClick={() => setMenu("contact")} className={`${menu === "contact" ? "active" : ""}`}>Contact Us</a>
            </ul>
            <div className="navbar-right">
                <img src={assets.search_icon} alt="Search" onClick={() => setIsSearchOpen(true)} />
                <Link to='/cart' className='navbar-search-icon'>
                    <img src={assets.basket_icon} alt="" />
                    <div className={getTotalCartAmount() > 0 ? "dot" : ""}></div>
                </Link>
                {loggedInUser ? (
                    <button onClick={handleLogout} style={{ padding: '10px 30px', border: '1px solid #FF4C24', borderRadius: '50px', fontSize: '16px', color: '#49557E', background: 'transparent', cursor: 'pointer', transition: '0.3s'}}>
                        Logout
                    </button>
                ) : (
                    <button onClick={() => setShowLogin(true)} style={{ padding: '10px 30px', border: '1px solid #FF4C24', borderRadius: '50px', fontSize: '16px', color: '#49557E', background: 'transparent', cursor: 'pointer', transition: '0.3s'}}>
                        Sign In
                    </button>
                )}
            </div>
            {isSearchOpen && (
                <div className="search-modal">
                    <input type="text" value={searchQuery} onChange={handleSearchChange} placeholder="Search for a dish..." />
                    <button onClick={handleSearch}>Search</button>
                    <button onClick={closeSearch}>Close Search</button>
                    {filteredItems.map(item => (
                        <div key={item.food_id}>{item.food_name}</div>
                    ))}
                </div>
            )}
        </div>
    );
}

export default Navbar;
